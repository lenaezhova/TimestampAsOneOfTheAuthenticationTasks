#pragma once
#include <iostream>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <vector>
#include <fstream>
using namespace std;
namespace hash {
    class Hash {
    public:
        long getHash(string s);
    };
    long Hash::getHash(string s) {
            s += " ";
            long long slength = s.length();
            long long hex = 0;
            for (int i = 0; i < slength; i++) {
                hex = hex + abs(s[i]);
            }
            while (hex % slength == 0) slength++;
            return hex % slength;
    }
}




