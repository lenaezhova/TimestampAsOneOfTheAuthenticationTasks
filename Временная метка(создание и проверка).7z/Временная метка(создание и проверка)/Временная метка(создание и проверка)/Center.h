#pragma warning(disable : 4996)
#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include "Keys.h"
#include <conio.h>
#include <time.h>
#include <stdio.h>
#include "Hash.h"
using namespace std;
using namespace keys;
using namespace hash;
namespace timestamp {
	Keys keys;
	Hash hash;
	class Timestamp {
		char* clock();
	public:
		bool setCertificate(long h);
	};
	char* Timestamp::clock() {
		time_t td;
		td = time(0);
		return ctime(&td);
	}
    bool Timestamp::setCertificate(long h)
	{
		ofstream out1;
		out1.open("TextFromCenter.txt");
		char* timeS = clock();
		out1 << h << " ";
		out1 << timeS;
		out1.close();
		long hex = hash.getHash("TextFromCenter.txt");
		vector<long long> keyss = keys.getKeys(hex);
		long p = keyss[0];
		long g = keyss[1];
		long y = keyss[2];
		long closeKey = keyss[3];
		long k = keyss[4];
		long long g_pow_k = pow(g, k);
		long w = g_pow_k % p;
		long z = p - 1;
		bool il = false;
		int t = 0;
		while (il == false) {
			if ((k * t - 1 > 0) && ((k * t - 1) % z == 0))il = true;
			else t++;
		}
		long s = ((abs(hex - closeKey * w)) * t) % (p - 1);
		ofstream out2;
		out2.open("Stamp.txt");
		out2 << w << " " << s;
		out2.close();
		ofstream out3;
		out3.open("OpenKeys.txt");
		out3 << p << " " << g << " " << y;
		out3.close();
		return true;
	}
}
