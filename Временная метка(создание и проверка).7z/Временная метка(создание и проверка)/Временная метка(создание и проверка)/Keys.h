#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <cmath>
using namespace std;

namespace keys {
	class Keys {
		int random(long h);
		bool simple(unsigned long n);
		int NOD(int a, int b);
	public:
		vector<long long> getKeys(long h);
	};
	int Keys::NOD(int a, int b)
	{
		while (a != 0 and b != 0) {
			if (a > b) a = a % b;
			else b = b % a;
		}
		return (a + b);
	}
	int Keys::random(long h) {
		long long p;
		srand(time(NULL));
		for (unsigned long i = 1; i <= 100000; i++)
		{
			p = h + 2 + rand() % (h + 22 - h + 1); 
			while (!simple(p)) p = h + 2 + rand() % (h + 22 - h + 1);
			break;
		}
		return p;
	}
	bool Keys::simple(unsigned long n)
	{
		if (n < 4) return false;
		for (unsigned long j = 2; j * j <= n; j++)
			if (n % j == 0) return false;
		return true;
	}
	vector<long long> Keys::getKeys(long h) {
		long p = random(h);
		long long g;
		long long x;
		long long k;
		if (p > 10) {
			g = 2 + rand() % (10 - 2 + 1);
			while (!(NOD(g, p) == 1)) g = 2 + rand() % (10 - 2 + 1);
			x = 2 + rand() % (10 - 2 + 1);
			k = 2 + rand() % (10 - 2 + 1);			
			while (!(NOD(k, p - 1) == 1)) k = 2 + rand() % (10 - 2 + 1);
		}
		else {
			g = 2 + rand() % (p - 2 + 1);
			while (!(NOD(g, p) == 1)) g = 2 + rand() % (p - 2 + 1);
			x = 2 + rand() % (p - 1 - 2 + 1);
			k = 2 + rand() % (p - 1 - 2 + 1);
			while (!(NOD(k, p - 1) == 1)) k = 2 + rand() % (p - 1 - 2 + 1);
		}
		long long g_pow_x = pow(g, x);
		long long y = g_pow_x % p;
		vector<long long> keys = { p, g, y, x, k };
		return keys;
	}
}
